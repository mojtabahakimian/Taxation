﻿namespace TaxCollectData.Library.Enums
{
    public enum InvoicePattern
    {
        SALES,
        CURRENCY_SALES,
        GOLD,
        CONTRACTING,
        SERVICE_BILLS,
        PLANE_TICKETS
    }
}