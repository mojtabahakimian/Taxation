﻿namespace TaxCollectData.Library.Enums
{
    public enum PayType
    {
        CASH,
        CREDIT,
        ELECTRONIC,
        FACILITY,
        OFFSET
    }
}