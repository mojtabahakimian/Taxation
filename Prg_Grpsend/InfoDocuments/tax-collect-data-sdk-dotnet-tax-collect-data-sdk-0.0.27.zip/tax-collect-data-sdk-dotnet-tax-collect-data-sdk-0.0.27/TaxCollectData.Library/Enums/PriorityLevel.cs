﻿namespace TaxCollectData.Library.Enums;

public enum PriorityLevel
{
    NORMAL, HIGH
}