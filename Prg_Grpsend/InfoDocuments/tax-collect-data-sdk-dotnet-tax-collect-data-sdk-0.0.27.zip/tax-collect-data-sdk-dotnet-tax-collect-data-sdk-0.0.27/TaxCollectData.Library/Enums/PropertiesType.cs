﻿namespace TaxCollectData.Library.Enums;

public enum PropertiesType
{
    NORMAL, GSB
}