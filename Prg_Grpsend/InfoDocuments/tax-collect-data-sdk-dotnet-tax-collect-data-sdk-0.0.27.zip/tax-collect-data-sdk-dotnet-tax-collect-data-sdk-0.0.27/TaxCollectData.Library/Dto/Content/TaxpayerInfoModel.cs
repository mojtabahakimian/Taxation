namespace TaxCollectData.Library.Dto.Content;

public class TaxpayerInfoModel
{
    public string TaxpayerName { get; set; }
    public int TaxpayerProfileStatus { get; set; }
    public bool TaxpayerCallStatus { get; set; }
    public bool TaxpayerArticle2Status { get; set; }
}