namespace TaxCollectData.Library.Dto.Content;

public class ShippingGoodDto
{
    public string? Sgid { get; init; }
    public string? Sgt { get; init; }
}