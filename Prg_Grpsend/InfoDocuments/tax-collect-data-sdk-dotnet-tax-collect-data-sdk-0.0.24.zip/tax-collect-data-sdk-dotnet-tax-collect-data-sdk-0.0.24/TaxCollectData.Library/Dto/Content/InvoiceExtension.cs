﻿namespace TaxCollectData.Library.Dto.Content;

public record InvoiceExtension
{
}