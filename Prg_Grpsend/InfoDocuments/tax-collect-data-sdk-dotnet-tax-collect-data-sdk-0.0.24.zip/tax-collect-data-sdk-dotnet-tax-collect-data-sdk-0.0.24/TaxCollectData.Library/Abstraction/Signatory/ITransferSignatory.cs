﻿namespace TaxCollectData.Library.Abstraction.Signatory;

public interface ITransferSignatory : ISignatory
{
    
}