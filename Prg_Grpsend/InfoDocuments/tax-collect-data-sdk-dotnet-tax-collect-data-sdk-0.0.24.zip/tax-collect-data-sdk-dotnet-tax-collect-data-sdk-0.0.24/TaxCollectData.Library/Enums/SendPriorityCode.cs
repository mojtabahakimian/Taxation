﻿namespace TaxCollectData.Library.Enums
{
    public enum SendPriorityCode
    {
        ACCORDING_TO_TIMELINE,
        MAX_TIMEOUT_AFTER_STORE,
        INSTANTLY_AFTER_STORE
    }
}