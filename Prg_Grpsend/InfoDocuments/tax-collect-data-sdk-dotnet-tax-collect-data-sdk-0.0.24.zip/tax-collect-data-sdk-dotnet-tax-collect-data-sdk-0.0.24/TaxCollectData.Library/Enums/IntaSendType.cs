﻿namespace TaxCollectData.Library.Enums
{
    public enum IntaSendType
    {
        ONLINE_STRAIGHT,
        ONLINE_TSP,
        OFFLINE_STRAIGHT,
        OFFLINE_TSP
    }
}