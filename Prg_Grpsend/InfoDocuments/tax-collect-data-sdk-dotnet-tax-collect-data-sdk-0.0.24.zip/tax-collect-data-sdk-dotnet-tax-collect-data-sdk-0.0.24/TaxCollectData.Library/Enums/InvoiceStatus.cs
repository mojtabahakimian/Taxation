﻿namespace TaxCollectData.Library.Enums
{
    public enum InvoiceStatus
    {
        CONFIRM,
        SYSTEM_CONFIRM,
        REJECT,
        PENDING
    }
}